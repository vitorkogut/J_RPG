package combate;

import java.util.Random;


public class TextosCombate {
    
    Random randomiza = new Random();
    
    private String returnTxt;
    
    private String acertoCabecaGuerreiro1 = "Você rapidamente desfere um ataque direcionado a cabeça o inimigo,deixando-o atordoado por 1 turno e causando ";
    private String acertoCabecaGuerreiro2 = "Você ataca o inimigo com sua espada, acertando a cabeça de seu inimigo enquanto ele tentava se esquivar, deixando-o confuso por 1 turno e causando ";
    private String acertoPeitoGuerreiro1 = "Em uma tentativa de acertar a cabeça de seu inimigo, ele defende sua cabeça mas expõe seu peito , abrindo uma oportunidade para você acertar-lo, causando ";
    private String acertoPeitoGuerreiro2 = "Com muita força, você acerta sua espada no peito do seu inimigo, causando ";
    private String acertoBracoGuerreiro1 = "Seu inimigo com o objetivo de esquivar de sua espada , acaba deixando seu braço no caminho, onde sua espada o corta, diminuindo então sua capacidade de ataque e causando ";
    private String acertoBracoGuerreiro2 = "Você desfere um corte certeiro no braço de seu inimigo, diminuindo sua capacidade de ataque e causando ";
    private String defesaGuerreiro1 = "O inimigo com muita raiva avança em sua direção, porém você rapidamente levanta seu escudo, bloqueando seu ataque.";
    private String defesaGuerreiro2 = "Com muita destreza e força, você consegue bloquear o ataque de seu inimigo com muita perfeição, refletindo então seu ataque e deixando-o atordoado por 2 turnos";
    private String erroGuerreiro = "Você desfere um golpe lateral, porém seu inimigo consegue esquivar.";
    private String erroCritGuerreiro = "Ao tentar um corte rapido você escorrega e erra seu golpe, caindo no chão. (PERDA 1 TURNO)";
    private String vitoriaGuerreiro = "Ao desferir o ultimo golpe seu inimigo cai de dor no chão.";
    
    
    private String acertoCabecaArqueiro1 = "Você prepara seu arco,com muita paciência, e então solta a flecha, a flecha acerta a cabeça de seu inimigo deixando-o atordoado por 1 turno e causando ";
    private String acertoCabecaArqueiro2 = "Você atira sua flecha, o inimigo quando percebe faz de tudo para tentar desviar, mas sem sucesso, a flecha acaba acertando em cheio sua cabeça deixando-o atordoado por 1 turno e causando ";
    private String acertoPeitoArqueiro1 = "Você puxa sua flecha, solta, ela viaja como a velocidade da luz, e acerta em cheio seu inimigo, causando ";
    private String acertoPeitoArqueiro2 = "ataque peito arq 2 ";
    private String acertoBracoArqueiro1 = "ataque braco arq 1 ";
    private String acertoBracoArqueiro2 = "ataque braco arq 2 ";
    private String defesaArqueiro1 = "O inimigo avança com um olhar sanguinario, porém você é mais rapido e desvia de seu golpe.";
    private String defesaArqueiro2 = "Ao tentar um ataque seu inimigo acaba errando e perdendo sua postura perdendo 2 turnos.";
    private String erroArqueiro = "Você atira a flexa com rapidez, porém seu inimigo preve seu movimento e desvia com facilidade.";
    private String erroCritArqueiro = "Você prepara o arco para mais um desparo, porém a corda do seu arco se desprende fazendo com que voê erre e perca um turno arrumando o mesmo.";
    private String vitoriaArqueiro = "Um ultimo desparo e seu inimigo cai perante você.";
    
    private String acertoCabecaMago1 = "ataque cabeça mago 1";
    private String acertoCabecaMago2 = "ataque cabeça mago 2 ";
    private String acertoPeitoMago1 = "ataque peito mago 1";
    private String acertoPeitoMago2 = "ataque peito mago 2";
    private String acertoBracoMago1 = "ataque braco mago 1";
    private String acertoBracoMago2 = "ataque braco mago 2";
    private String defesaMago1 = "defesa mago 1 ";
    private String defesaMago2 = "defesa mago 2";
    private String erroMago = "erro do mago";
    private String erroCritMago = "erro crit do mago";
    private String vitoriaMago = "mago eh implacavel carai";
    
    private String potion = "Você utiliza sua potion recuperando sua vida.";
    private String bomba = "Você arremesa uma bomba em seu inimigo.";
    private String faca = "Você arremesa uma faca que acerta o peito de seu inimigo.";
    /*
    private String acertoGue = "Você acerta um golpe de espada retirando ";
    private String acertoMago = "Você acerta uma Soul Arrow retirando ";
    private String acertoArq = "Você acerta um disparo retirando ";
    
    private String acertoCritico= "Seu ataque acertou em cheio o inimigo causando ";
    
    private String erro = "Seu ataque é falho.";
    private String erroCritico = "Você erra seu ataque e em seguida perde o equilibrio ( -1 round ).";
    
    private String vitória = "Após esse golpe o inimigo cai em dor.";
    */
    
     public String getTextoCombate(int classe, int tipo){
         
        int txtRandom = randomiza.nextInt(2); //randomiza o txt
        
        switch(classe){
        
            case 1: //guerreiro
                switch(tipo){
                    case 0://cabeça
                        if(txtRandom == 0){
                            returnTxt = acertoCabecaGuerreiro1;
                        }else{
                            returnTxt = acertoCabecaGuerreiro2;
                        }
                        break;
                        
                    case 1://peito
                        if(txtRandom == 0){
                            returnTxt = acertoPeitoGuerreiro1;
                        }else{
                            returnTxt = acertoPeitoGuerreiro2;
                        }
                        break;
                        
                    case 2://braco
                        if(txtRandom == 0){
                            returnTxt = acertoBracoGuerreiro1;
                        }else{
                            returnTxt = acertoBracoGuerreiro2;
                        }
                        break;
                        
                    case 3://defesa
                        returnTxt = defesaGuerreiro1;
                        break;
                    
                    case 4://defesa 2
                        returnTxt = defesaGuerreiro2;
                        break;
                        
                    case 5://erro
                        returnTxt = erroGuerreiro;
                        break;
                        
                    case 6://erro crit
                        returnTxt = erroCritGuerreiro;
                        break;
                        
                    case 7://vitoria
                        returnTxt = vitoriaGuerreiro; 
                        break;
                        
                    case 8://potion
                        returnTxt = potion;
                        break;
                        
                    case 9://bomba
                        returnTxt = bomba;
                        break;
                        
                    case 10://faca
                        returnTxt = faca;
                        break;
                        
                }
                //returnTxt = acertoGue;
            break;
            
            case 3: //arqueiro
                switch(tipo){
                    case 0://cabeça
                        if(txtRandom == 0){
                            returnTxt = acertoCabecaArqueiro1;
                        }else{
                            returnTxt = acertoCabecaArqueiro2;
                        }
                        break;
                        
                    case 1://peito
                        if(txtRandom == 0){
                            returnTxt = acertoPeitoArqueiro1;
                        }else{
                            returnTxt = acertoPeitoArqueiro2;
                        }
                        break;
                        
                    case 2://braco
                        if(txtRandom == 0){
                            returnTxt = acertoBracoArqueiro1;
                        }else{
                            returnTxt = acertoBracoArqueiro2;
                        }
                        break;
                        
                    case 3://defesa
                        returnTxt = defesaArqueiro1;
                        break;
                    
                    case 4://defesa 2
                        returnTxt = defesaArqueiro2;
                        break;
                        
                    case 5://erro
                        returnTxt = erroArqueiro;
                        break;
                        
                    case 6://erro crit
                        returnTxt = erroCritArqueiro;
                        break;
                        
                    case 7://vitoria
                        returnTxt = vitoriaArqueiro; 
                        break;
                        
                    case 8://potion
                        returnTxt = potion;
                        break;
                        
                    case 9://bomba
                        returnTxt = bomba;
                        break;
                        
                    case 10://faca
                        returnTxt = faca;
                        break;
                }
                //returnTxt = acertoMago;
            break;
            
            case 2: //mago
                switch(tipo){
                    case 0://cabeça
                        if(txtRandom == 0){
                            returnTxt = acertoCabecaMago1;
                        }else{
                            returnTxt = acertoCabecaMago2;
                        }
                        break;
                        
                    case 1://peito
                        if(txtRandom == 0){
                            returnTxt = acertoPeitoMago1;
                        }else{
                            returnTxt = acertoPeitoMago2;
                        }
                        break;
                        
                    case 2://braco
                        if(txtRandom == 0){
                            returnTxt = acertoBracoMago1;
                        }else{
                            returnTxt = acertoBracoMago2;
                        }
                        break;
                        
                    case 3://defesa
                        returnTxt = defesaMago1;
                        break;
                    
                    case 4://defesa 2
                        returnTxt = defesaMago2;
                        break;
                        
                    case 5://erro
                        returnTxt = erroMago;
                        break;
                        
                    case 6://erro crit
                        returnTxt = erroCritMago;
                        break;
                        
                    case 7://vitoria
                        returnTxt = vitoriaMago; 
                        break;
                        
                    case 8://potion
                        returnTxt = potion;
                        break;
                        
                    case 9://bomba
                        returnTxt = bomba;
                        break;
                        
                    case 10://faca
                        returnTxt = faca;
                        break;
                }
                //returnTxt = acertoArq;
            break;
            
            /*
            case 3: //hit crit gue
                returnTxt = acertoCritico;
            break;
            
            case 4:
                returnTxt = erro;
            break;
            
            case 5:
                returnTxt = erroCritico;
            break;
            
            case 6:
                returnTxt = vitória;
            break;
            */
        }
        
        return returnTxt;
    
    
     }
}



